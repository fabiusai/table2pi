# Excel ➜ SVG Table Generator

Web‑app React che trasforma un foglio Excel in una o più immagini **SVG** (2048×912 px) usando due layout grafici (“Light” e “Strong”).

## Avvio rapido

```bash
npm install         # installa dipendenze
npm run dev         # avvia in locale (http://localhost:5173)
```

## Deploy statico (GitHub Pages)

1. Imposta il campo `homepage` in `package.json`:
   ```json
   "homepage": "https://<TUO‑USERNAME>.github.io/<REPO>"
   ```
2. Sostituisci `<REPO>` in `vite.config.js` col nome del repo.
3. Esegui:
   ```bash
   npm run deploy
   ```

## Funzionalità

* Upload `.xlsx / .xls`
* Selezione layout (“Light” / “Strong”)
* Suddivisione automatica con header ripetuto
* Download dei singoli SVG
* UI responsive, palette giallo/blu, font *Avenir Next LT Pro*